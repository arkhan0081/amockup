<?php $__env->startSection('title'); ?>
    <?php echo $page->title; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('metas'); ?>
    <?php if($page->index_allowed!=1): ?>
        <meta name="robots" content="noindex">
        <meta name="googlebot" content="noindex">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <?php echo $page->other_css; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('slider'); ?>
    <style>
        #hero {
            width: 100%;
            height: 70vh;
            background-image: url("<?php echo e(asset("$page->image")); ?>");
            border-bottom: 2px solid #fcebe3;
            margin: 72px 0 -72px 0;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            background-attachment: fixed;
        }
        hr.new{
            border: 1px solid #ffffff!important;
            background: white;

        }
    </style>
    <section id="hero" class="d-flex align-items-center">

        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-5 pt-lg-0 order-2 order-lg-1">
                    <h1 class="text-center" style="color: white;font-family: Arial;font-size: 46px;line-height: 60px;font-weight: 400;"><?php echo e($page->sliderText); ?></h1>
                    <hr class="new">
                </div>
                
                
                
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Contact Us Section ======= -->
<section id="contact" class="contact">
    <div class="container">

        <div class="section-title" data-aos="fade-up">
            <h2>Contact Us</h2>
            <p>Contact us the get started</p>
        </div>

        <div class="row">
        <?php if(Session::has('message')): ?>
                <div class="alert alert-<?php echo e(Session::get('message-type')); ?> alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button"> × </button>
                    <i class="glyphicon glyphicon-<?php echo e(Session::get('message-type') == 'success' ? 'ok' : 'remove'); ?>"></i>  <?php echo e(Session::get('message')); ?>

                </div>
        <?php endif; ?>
            <div class="col-lg-12 d-flex align-items-stretch text-center" data-aos="fade-up" data-aos-delay="100">
               <div class="info">
                   <?php echo $page->content; ?>

               </div>
            </div>

            <div class="col-lg-12 mt-5">
                <form action="<?php echo e(route('contactUs')); ?>" method="post" role="form" class="php-email-form">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="name">NAME: *</label>
                            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">Email: *</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" data-rule="email" data-msg="Please enter a valid email" />
                             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name">HOW CAN WE HELP YOU? *</label>
                        <textarea class="form-control  <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message" rows="10" data-rule="required" data-msg="Please write something for us"></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-center"><button type="submit">Send Message</button></div>
                </form>
            </div>

        </div>

    </div>
</section><!-- End Contact Us Section -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $page->other_js; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mockup\resources\views/contact.blade.php ENDPATH**/ ?>