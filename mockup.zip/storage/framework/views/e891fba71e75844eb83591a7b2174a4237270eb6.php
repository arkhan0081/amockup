<?php $__env->startSection('content'); ?>
    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
        <div class="container">

            <div class="section-title" data-aos="fade-up">
                <h2>Contact Us</h2>
                <p>Contact us the get started</p>
            </div>

            <div class="row">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-<?php echo e(Session::get('message-type')); ?> alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"> × </button>
                        <i class="glyphicon glyphicon-<?php echo e(Session::get('message-type') == 'success' ? 'ok' : 'remove'); ?>"></i>  <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>

                <div class="col-lg-12 mt-5">
                    <form method="post" action="<?php echo e(route('settings.update')); ?>" role="form" class="php-email-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group <?php echo e($errors->has('SEND_MAIL_TO') ? 'has-error': ''); ?> ">
                            <label>SEND EMAIL TO</label>
                            <input type="email" class="form-control" name="SEND_MAIL_TO"
                                   value="<?php echo e(old('SEND_MAIL_TO',Setting::get('SEND_MAIL_TO'))); ?>">
                            <?php if($errors->has('SEND_MAIL_TO')): ?>
                                <span class="help-block">
					       <strong><?php echo e($errors->first('SEND_MAIL_TO')); ?></strong>
				               </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('SCRIPT_FB') ? 'has-error': ''); ?> ">
                            <label>FACE BOOK PIXEL SCRIPT</label>
                            <textarea type="text" class="form-control" name="SCRIPT_FB"><?php echo e(Setting::get('SCRIPT_FB')); ?></textarea>
                        <?php if($errors->has('SCRIPT_FB')): ?>
                                <span class="help-block">
					       <strong><?php echo e($errors->first('SCRIPT_FB')); ?></strong>
				               </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('SCRIPT_GOOGLE') ? 'has-error': ''); ?> ">
                            <label>GOOGLE ANALYTICS CODE</label>
                            <textarea type="text" class="form-control" name="SCRIPT_GOOGLE"><?php echo e(Setting::get('SCRIPT_GOOGLE')); ?></textarea>
                            <?php if($errors->has('SCRIPT_GOOGLE')): ?>
                                <span class="help-block">
					       <strong><?php echo e($errors->first('SCRIPT_GOOGLE')); ?></strong>
				               </span>
                            <?php endif; ?>
                        </div>

                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>
                    </form>
                    <!--ads-->
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mockup\resources\views/settings.blade.php ENDPATH**/ ?>