<?php $__env->startSection('title'); ?>
<?php echo $page->title; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('metas'); ?>
    <?php if($page->index_allowed!=1): ?>
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <?php echo $page->other_css; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('slider'); ?>
    <style>
        #hero {
            width: 100%;
            height: 70vh;
            background-image: url("<?php echo e(asset("$page->image")); ?>");
            border-bottom: 2px solid #fcebe3;
            margin: 72px 0 -72px 0;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            background-attachment: fixed;
        }
        hr.new{
           border: 1px solid #ffffff!important;
            background: white;

        }
    </style>
    <section id="hero" class="d-flex align-items-center">

        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-5 pt-lg-0 order-2 order-lg-1">
                    <h1 class="text-center" style="color: white;font-family: Arial;font-size: 46px;line-height: 60px;font-weight: 400;"><?php echo e($page->slider_text); ?></h1>
                <hr class="new">
                </div>



            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= About Section ======= -->
<section id="about" class="about">
    <div class="container">

        <div class="row justify-content-between">
        <?php echo $page->content; ?>

        </div>

    </div>
</section><!-- End About Section -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $page->other_js; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mockup\resources\views/index.blade.php ENDPATH**/ ?>