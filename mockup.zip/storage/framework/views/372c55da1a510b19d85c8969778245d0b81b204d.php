<div>
    User Submitted Details
    Name: <?php echo e($data['name']); ?><br>
    Email: <?php echo e($data['email']); ?><br>
    Message: <?php echo e($data['message']); ?><br>
</div>
<?php /**PATH C:\xampp\htdocs\mockup\resources\views/emails/contact.blade.php ENDPATH**/ ?>