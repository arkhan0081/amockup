<button class="btn btn-danger" onclick="frmdlt<?php echo e($page->id); ?>.submit();"  title="Delete"><i class="fa fa-trash-o"></i></button>
<form onSubmit="if(!confirm('Is the form filled out correctly?')){return false;}" name="frmdlt<?php echo e($page->id); ?>" action="<?php echo e(route('pages.destroy', $page->id)); ?>" method="post">
    <?php echo method_field('delete'); ?>

    <?php echo e(csrf_field()); ?>

</form>
<?php /**PATH C:\xampp\htdocs\mockup\resources\views/pages/delete.blade.php ENDPATH**/ ?>