<div>
    User Submitted Details<br>
    Name: {{ $data['name'] }}<br>
    Email: {{ $data['email'] }}<br>
    Message: {{ $data['message'] }}<br>
</div>
